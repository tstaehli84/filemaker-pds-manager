@echo off
setlocal
cd /d "%~dp0"
title Install PDS Manager for FileMaker
if not exist "%~dp0PDS_Manager\info.json" (
  echo Please extract the entire ZIP first, then run Install.cmd.
  pause
  exit /b 1
)
if not defined LOCALAPPDATA (
  echo Windows could not locate your local application data folder.
  pause
  exit /b 1
)
echo PDS Manager for FileMaker Pro 26.0.3 or later
 echo.
echo Close FileMaker before continuing. No administrator access is required.
pause
set "PDS_DEST=%LOCALAPPDATA%\FileMaker\Extensions\AddonModules\PDS_Manager"
if exist "%PDS_DEST%" (
  set "PDS_BACKUP=%LOCALAPPDATA%\FileMaker\Extensions\AddonModules-Backups\PDS_Manager-%RANDOM%-%RANDOM%"
  call :backup
  if errorlevel 1 goto failure
)
robocopy "%~dp0PDS_Manager" "%PDS_DEST%" /E /R:1 /W:1 /XJ /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 goto failure
echo.
echo Installed successfully.
echo Open FileMaker, enter Layout mode, open Add-ons, and click +.
echo Choose PDS Manager, then drag it onto your layout.
pause
exit /b 0
:backup
robocopy "%PDS_DEST%" "%PDS_BACKUP%" /E /R:1 /W:1 /XJ /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 exit /b 1
exit /b 0
:failure
echo Installation could not finish. Your existing add-on was not intentionally deleted.
echo Check that FileMaker is closed and that your account can write to LocalAppData.
pause
exit /b 1
